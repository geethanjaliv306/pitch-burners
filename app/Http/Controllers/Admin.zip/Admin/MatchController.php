<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use App\Models\MatchGame;
use App\Models\OrganizerMember;
use App\Models\Player;
use App\Models\ScheduleMatch;
use App\Models\Team1Detail;
use App\Models\TournamentTeam;
use App\Models\Team2Detail;
use App\Models\Team;
use App\Models\BallByBall;
use App\Models\MatchScore;
use App\Models\Tournament;
use App\Models\User;
use App\Models\Venue;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class MatchController extends Controller
{

    public function index($match_id)
     {
        $match = ScheduleMatch::with(['teamOne.players', 'teamTwo.players', 'venue'])
                    ->where('id', $match_id)
                    ->firstOrFail();

        $teamAPlayers = Player::where('team_id', $match->teamOne->id)->get();
        $teamBPlayers = Player::where('team_id', $match->teamTwo->id)->get();

        $users = User::where('role', 2)->get();

        return view('admin.startmatch', [
            'match' => $match,
            'teamAPlayers' => $teamAPlayers,
            'teamBPlayers' => $teamBPlayers,
            'users' => $users,
            'tournament_id' => $match->tournament_id
        ]);
    }

    public function getPlayers($team_id)
     {
        $players = Player::where('team_id', $team_id)->get();
        return response()->json($players);
    }

    public function startMatch(Request $request)
     {
        $validatedData = $request->validate([
            'matchDetails.matchType' => 'required|string',
           'matchDetails.noOfOvers' => 'nullable|numeric|min:1',
            'matchDetails.ground' => 'nullable|string',
            'matchDetails.dateTime' => 'nullable|date',
            'matchDetails.tossWinner' => 'required|exists:teams,id',
            'matchDetails.tossChoice' => 'required|in:bat,bowl',
            'matchDetails.tournament_id' => 'required|exists:tournaments,id',
            'matchDetails.schedule_match_id' => 'required',
            'matchDetails.round_id' => 'required',
            'matchDetails.group_id' => 'required',
            'matchDetails.overs_per_bowler' => 'required',
        ], [
            'matchDetails.matchType.required' => 'Match type is required.',
            'matchDetails.matchType.string' => 'Match type must be a valid string.',
            'matchDetails.noOfOvers.numeric' => 'Number of overs must be a numeric value.',
            'matchDetails.noOfOvers.min' => 'Number of overs must be at least 1.',
            'matchDetails.ground.string' => 'Ground name must be a valid string.',
            'matchDetails.dateTime.date' => 'Please provide a valid date and time.',
            'matchDetails.dateTime.after_or_equal' => 'Match date and time must be today or in the future.',
            'matchDetails.tossWinner.required' => 'Please select a team that won the toss.',
            'matchDetails.tossChoice.required' => 'Please select the choice of toss (Bat or Bowl).',
            'matchDetails.tossChoice.in' => 'Toss choice must be either "bat" or "bowl".',
        ]);


        $tossWinnerId = $validatedData['matchDetails']['tossWinner'];
        $tossChoice = $validatedData['matchDetails']['tossChoice'];

        $battingTeamId = $tossChoice === 'bat' ? $tossWinnerId : ($tossWinnerId == $request->teamA['team_id'] ? $request->teamB['team_id'] : $request->teamA['team_id']);
        $bowlingTeamId = $battingTeamId == $request->teamA['team_id'] ? $request->teamB['team_id'] : $request->teamA['team_id'];

        $matchGame = MatchGame::create([
            'tournament_id' => $validatedData['matchDetails']['tournament_id'],
            'schedule_match_id' => $validatedData['matchDetails']['schedule_match_id'],
            'round_id' => $validatedData['matchDetails']['round_id'],
            'overs_per_bowler' => $validatedData['matchDetails']['overs_per_bowler'],
            'group_id' => $validatedData['matchDetails']['group_id'],
            'teamA_id' => $request->teamA['team_id'],
            'teamB_id' => $request->teamB['team_id'],
            'venue' => $validatedData['matchDetails']['ground'] ?? null,
            'match_date_time' => $validatedData['matchDetails']['dateTime'] ?? null,
            'type' => $validatedData['matchDetails']['matchType'],
            'overs' => $validatedData['matchDetails']['noOfOvers'] ?? null,
            'first_umpire' => $request['matchDetails']['umpires']['firstUmpire'] ?? null,
            'second_umpire' => $request['matchDetails']['umpires']['secondUmpire'] ?? null,
            'third_umpire' => $request['matchDetails']['umpires']['thirdUmpire'] ?? null,
            'first_scorer' => $request['matchDetails']['scorers']['firstScorer'] ?? null,
            'second_scorer' => $request['matchDetails']['scorers']['secondScorer'] ?? null,
            'toss' => $tossWinnerId,
            'batting' => $battingTeamId,
            'bowling' => $bowlingTeamId,
            'status' => 'Active',
        ]);

           $schedulematch = ScheduleMatch::where('id', $validatedData['matchDetails']['schedule_match_id'])
          ->update(['status' => 'Active']);


        foreach (['teamA', 'teamB'] as $teamKey) {
            $teamDetailsClass = $teamKey === 'teamA' ? Team1Detail::class : Team2Detail::class;

            foreach ($request->{$teamKey}['players'] as $player) {
                $teamDetailsClass::create([
                    'match_id' => $matchGame->id,
                    'team_id' => $request->{$teamKey}['team_id'],
                    'player_id' => $player['id'],
                    'captain' => $player['id'] == $request->{$teamKey}['captain'] ? 1 : 0,
                    'wicketkeeper' => $player['id'] == $request->{$teamKey}['keeper'] ? 1 : 0,
                    '12th_man' => in_array($player['id'], $request->{$teamKey}['twelfthMen']) ? 1 : 0,
                ]);
            }
        }

        return response()->json(['success' => true, 'message' => 'Match started successfully!', 'match_id' => $matchGame->id]);
    }


    public function match_view(Request $request)
     {
        // API URL
        $apiUrl = 'https://pitchburners.geohomefinder.com/api/Match/Fixtures';

        // Fetch API data
        $response = Http::get($apiUrl);

        if ($response->successful()) {
            $apiData = $response->json(); // Decode the API response
        } else {
            abort(500, 'Failed to fetch match data from the API.');
        }

        // Extract necessary data
        $matches = collect($apiData['matchFixtures']);
        $tournaments = collect($apiData['getSeasons']);
        $venues = collect($apiData['Venues']);
        $teams = collect($apiData['Teams']);

        // Selected Filters
        $selectedTournamentId = $request->get('tournament_id');
        $selectedTeamId = $request->get('team_id');
        $selectedVenueId = $request->get('venue_id');
        $selectedStatus = $request->get('status', 'Live'); // Default to 'Live'

        // Filter matches based on selected filters
        $filteredMatches = $matches->filter(function ($match) use ($selectedTournamentId, $selectedTeamId, $selectedVenueId, $selectedStatus) {
            $statusMatch = true;
            $tournamentMatch = true;
            $teamMatch = true;
            $venueMatch = true;

            // Filter by status
            if ($selectedStatus === 'Live') {
                $statusMatch = $match['status'] === 'active';
            } elseif ($selectedStatus === 'Completed') {
                $statusMatch = $match['status'] === 'completed' || $match['status'] === 'cancelled';
     } elseif ($selectedStatus === 'Upcoming') {
                $statusMatch = $match['status'] === 'scheduled';
            }

            // Filter by tournament
            if ($selectedTournamentId) {
                $tournamentMatch = $match['tournament_id'] == $selectedTournamentId;
            }

            // Filter by team
            if ($selectedTeamId) {
                $teamMatch = $match['team1'] == $selectedTeamId || $match['team2'] == $selectedTeamId;
            }

            // Filter by venue
            if ($selectedVenueId) {
                $venueMatch = $match['ground'] == $selectedVenueId;
            }

            return $statusMatch && $tournamentMatch && $teamMatch && $venueMatch;
        });

        // Pass data to the view
        return view('frontend.matches', compact(
            'filteredMatches',
            'tournaments',
            'venues',
            'teams',
            'selectedTournamentId',
            'selectedTeamId',
            'selectedVenueId',
            'selectedStatus'
        ));
    }

public function match_details($id)
{
    $match = ScheduleMatch::with(['teamOne', 'teamTwo', 'venue', 'tournament'])->findOrFail($id);

    $ScheduleMatch = ScheduleMatch::find($id);
    $liveMatch = MatchGame::where('schedule_match_id', $id)->first();

    $teamAPlayers = Player::where('team_id', $match->team1)->get();
    $teamBPlayers = Player::where('team_id', $match->team2)->get();

    $playing11TeamA = collect();
    $playing11TeamB = collect();
    $benchTeamA = collect();
    $benchTeamB = collect();
    $umpires = collect();
    $scorers = collect();
    $tossWinnerName = null;
    $tournamentName = null;
    $groundName = null;

    if ($liveMatch) {
        $team1PlayerIds = Team1Detail::where('match_id', $liveMatch->id)
            ->where('team_id', $ScheduleMatch->team1)
            ->where('12th_man', '0')
            ->pluck('player_id')
            ->toArray();

        $team2PlayerIds = Team2Detail::where('match_id', $liveMatch->id)
            ->where('team_id', $ScheduleMatch->team2)
            ->where('12th_man', '0')
            ->pluck('player_id')
            ->toArray();

        $playing11TeamA = Player::whereIn('id', $team1PlayerIds)->get();
        $playing11TeamB = Player::whereIn('id', $team2PlayerIds)->get();

        $benchTeamAplayers = Team1Detail::where('match_id', $liveMatch->id)
            ->where('team_id', $ScheduleMatch->team1)
            ->where('12th_man', '1')
            ->pluck('player_id')
            ->toArray();
        $benchTeamBplayers = Team2Detail::where('match_id', $liveMatch->id)
            ->where('team_id', $ScheduleMatch->team2)
            ->where('12th_man', '1')
            ->pluck('player_id')
            ->toArray();

        $benchTeamA = Player::whereIn('id', $benchTeamAplayers)->get();
        $benchTeamB = Player::whereIn('id', $benchTeamBplayers)->get();

        $umpireIds = array_filter([$liveMatch->first_umpire, $liveMatch->second_umpire, $liveMatch->third_umpire]);
        $scorerIds = array_filter([$liveMatch->first_scorer, $liveMatch->second_scorer]);

        $umpires = User::whereIn('id', $umpireIds)->get();
        $scorers = User::whereIn('id', $scorerIds)->get();

        $tossWinner = Team::find($liveMatch->toss);
        if ($tossWinner) {
            $tossWinnerName = $tossWinner->name;
        }
    }

    if ($match->tournament_id) {
        $tournament = Tournament::find($match->tournament_id);
        if ($tournament) {
            $tournamentName = $tournament->name;
        }
    }

    if ($match->ground) {
        $ground = Venue::find($match->ground);
        if ($ground) {
            $groundName = $ground->name;
        }
    }
$matchResult = null;
$teamOneScore = null;
$teamTwoScore = null;

if ($liveMatch) {
    $teamOneScore = MatchScore::where('match_id', $liveMatch->id)->where('team_id', $match->team1)->first();
    $teamTwoScore = MatchScore::where('match_id', $liveMatch->id)->where('team_id', $match->team2)->first();
}

if ($teamOneScore && $teamTwoScore) {
    if ($teamOneScore->total_runs == $teamTwoScore->total_runs) {
        // Match Draw
        $matchResult = "The match between {$match->teamOne->name} and {$match->teamTwo->name} ended in a draw.";
    } elseif ($teamOneScore->is_first_inning == 1 && $teamTwoScore->is_second_inning == 1) {
        if ($teamOneScore->total_runs > $teamTwoScore->total_runs) {
            // Team One wins by run margin
            $runDifference = $teamOneScore->total_runs - $teamTwoScore->total_runs;
            $matchResult = "{$match->teamOne->name} beat {$match->teamTwo->name} by {$runDifference} runs.";
        } else {
            // Team Two wins by wickets remaining
            $wicketsRemaining = 10 - $teamTwoScore->total_wickets;
            $matchResult = "{$match->teamTwo->name} beat {$match->teamOne->name} by {$wicketsRemaining} wickets.";
        }
    } elseif ($teamTwoScore->is_first_inning == 1 && $teamOneScore->is_second_inning == 1) {
        if ($teamTwoScore->total_runs > $teamOneScore->total_runs) {
            // Team Two wins by run margin
            $runDifference = $teamTwoScore->total_runs - $teamOneScore->total_runs;
            $matchResult = "{$match->teamTwo->name} beat {$match->teamOne->name} by {$runDifference} runs.";
        } else {
            // Team One wins by wickets remaining
            $wicketsRemaining = 10 - $teamOneScore->total_wickets;
            $matchResult = "{$match->teamOne->name} beat {$match->teamTwo->name} by {$wicketsRemaining} wickets.";
        }
    }
  }

    return view('frontend.match-centre', compact(
        'match',
        'liveMatch',
        'playing11TeamA',
        'teamAPlayers',
        'teamBPlayers',
        'playing11TeamB',
        'benchTeamA',
        'benchTeamB',
        'umpires',
        'scorers',
        'tossWinnerName',
        'tournamentName',
        'groundName',
        'matchResult'
    ));
}


}
