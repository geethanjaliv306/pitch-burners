<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContactUs extends Model
{
    use HasFactory;
    protected $table='contact_us';
    protected $fillable=[
        'name',
        'email',
        'phone',
        'message',
        'preferred_way_to_contact',
    ];
}
